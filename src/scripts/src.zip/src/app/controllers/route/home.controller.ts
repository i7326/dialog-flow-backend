import { JsonController, Get } from 'routing-controllers';

@JsonController('/find')
export class HomeController {
  @Get()
  public find(): any {
    return {
      message: 'test',
    };
  }
}
