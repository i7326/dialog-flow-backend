import { MicroframeworkSettings, MicroframeworkLoader } from 'microframework-w3tec';
import { useSocketServer } from 'socket-controllers';
import * as io from 'socket.io';
import * as socketSession from 'socket.io.session';
import { join } from 'path';


export const socketModule: MicroframeworkLoader = (settings: MicroframeworkSettings | undefined) => {
  if (settings) {
    const socket = io(settings.getData('server'), {
      pingInterval: 10000,
      pingTimeout: 5000,
      cookie: false,
    });

    // Set Socket Session
    const session = socketSession(settings.getData('sessionSetting'));
    socket.use(session.parser);

 /**
  *  socket.on('connection', (s) => {
  *    console.log('connected');
  *    s.on('disconnect', () => {
  *      console.log('user disconnected');
  *      socket.clients((error, clients) => {
  *      if (error) { throw error; }
  *        console.log(clients);
  *      });
  *    });
  *  });
  */

    useSocketServer(socket, {

       // Here Add Controllers for our Socket Server.
      controllers: [join(__dirname, '..', 'app/controllers/socket/*.controller{.js,.ts}')],

    });
  }
};
